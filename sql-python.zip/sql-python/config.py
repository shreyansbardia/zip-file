import os

settings = {
    'host': os.environ.get('ACCOUNT_HOST', 'https://cosmostest01hsbc.documents.azure.com:443/'),
    'master_key': os.environ.get('ACCOUNT_KEY', 'w37vybXC3HIuUl7lfzvo8AgYUlmZnrp7sQ597324rRisO9xAjfm5L0s1yZqGIfRwlHeINkAKvGH1ACDbq5TiUA=='),
    'database_id': os.environ.get('COSMOS_DATABASE', 'ToDoList'),
    'container_id': os.environ.get('COSMOS_CONTAINER', 'Items'),
}